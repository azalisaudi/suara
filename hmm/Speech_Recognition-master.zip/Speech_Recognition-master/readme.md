A Simple Speech Recognition Demo
================================

This is a simple speech recognition demo using HMM which is implemented using Python.

Requirement
------------

* [Python 2.7](https://www.python.org/download/releases/2.7.6/)
* [scikit-learn](http://scikit-learn.org/stable/)
* [SciPy](http://www.scipy.org/)

Usage
-------------
`./python main.py`